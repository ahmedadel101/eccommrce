export const Categories = [
  {categoryName:`Men's clothing`, categoryValue:`men's clothing` , image:`../../../../../assets/imgs/mens.jpg`},
  {categoryName:`Women's clothing` , categoryValue:`women's clothing` , image:`../../../../../assets/imgs/womans.jpg`},
  {categoryName:`Electronics` , categoryValue:`electronics` , image:`../../../../../assets/imgs/electronics.jpg`},
  {categoryName:`Jewelery` , categoryValue:`jewelery` , image:`../../../../../assets/imgs/Jewelery.jpg`}
]
